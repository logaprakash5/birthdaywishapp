import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import './bday.css'
import Caroselwish from '../carousels/caroselwish.js'
import Snowfall from 'react-snowfall'


export default function bday() {
  const [btninvisi,setbtninvisi] = useState(true);
  const [caroselinvisi,setcaroselinvisi] = useState(false);
  const [snow,setsnow] = useState(false);
  function action()
  {
    setbtninvisi(false);
    setcaroselinvisi(true);
    setsnow(true);
  }
  return (
    <div>
      <div className='nav'>
            <Link to="/home" style={{ color: 'black',textDecoration: 'none' }}><h1 className='bu'>Bliss. you</h1></Link>
            <ul>
            <Link to="/login" style={{ color: 'black' }}><li><a>LOGOUT</a></li></Link>
              <Link to="/seeme" style={{ color: 'black' }}><li><a>SEE MEEE</a></li></Link>
              <Link to="/us" style={{ color: 'black' }}><li><a>USSSSS</a></li></Link>
              <Link to="/wishes" style={{ color: '#F43839' }}><li><a>YOUMUUU</a></li></Link>
            </ul>
            {snow && <Snowfall color="yellow" snowflakeCount={500}/>}
            {caroselinvisi && <div className='caroselbox' ><Caroselwish/></div>}
            {btninvisi && <div class="box1" onClick={action}>This is for yomuuuuu birthday gal....</div>}
        </div>


    </div>
  )
}


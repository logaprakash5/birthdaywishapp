import React from 'react'
import { Link } from 'react-router-dom'
import { useEffect } from 'react';
import { ReactFloatingBalloons } from "react-floating-balloons";
import {FloatingTree} from '@floating-ui/react';

import ScriptTag from 'react-script-tag/lib/ScriptTag';
export default function () {
    
  return (
    <div>
      <div className='nav'>
            <Link to="/home" style={{ color: 'black',textDecoration: 'none' }}><h1 className='bu'>Bliss. you</h1></Link>
            <ul>
            <Link to="/login" style={{ color: 'black' }}><li><a>LOGOUT</a></li></Link>
              <Link to="/seeme" style={{ color: '#F43839' }}><li><a>SEE MEEE</a></li></Link>
              <Link to="/us" style={{ color: 'black' }}><li><a>USSSSS</a></li></Link>
              <Link to="/wishes" style={{ color: 'black' }}><li><a>YOUMUUU</a></li></Link>
            </ul>
      </div>
        <ReactFloatingBalloons
        count={8}
        colors={["yellow","green"]}
        popVolumeLevel={0.1}
      />
      <FloatingTree/>
    </div>
  )
}

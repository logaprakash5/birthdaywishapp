import Confetti from "react-confetti";
import React, { useState, useRef, useEffect,Component } from "react";
import './home.css'
import gift from '../images/gift.png'
import buchhi from '../images/buchhi.gif'
import { Link } from "react-router-dom";



export default function home() {
    const confetiRef = useRef(null);
    const [pop, setpop] = React.useState(false);
    const [gifthide,setgifthide] = useState(true);
    const [colorchange,setcolorchange] = useState(false);
    const [buchihide,setbuchihide] = useState(false);
    const [wish,setwish] =useState(false);
  function popout()
  {
    setpop(true);
    setgifthide(false);
    setcolorchange(true);
    setbuchihide(true);
    setTimeout(() => {
           setbuchihide(false);
    }, 5000);
    setTimeout(() => {
      setwish(true);
    }, 5000);
  }

  return (
    <div>
        <div className='nav'>
            <Link to="/home" style={{ color: 'black',textDecoration: 'none' }}><h1 className='bu'>Bliss. you</h1></Link>
            <ul>
            <Link to="/login" style={{ color: 'black' }}><li><a>LOGOUT</a></li></Link>
              <Link to="/seeme" style={{ color: 'black' }}><li><a>SEE MEEE</a></li></Link>
              <Link to="/us" style={{ color: 'black' }}><li><a>USSSSS</a></li></Link>
              <Link to="/wishes" style={{ color: 'black' }}><li><a>YOUMUUU</a></li></Link>
              
            </ul>
        </div>
        <div className={colorchange ? "content":"" } >
          <br></br>
          { gifthide && <img className='giftpng' src={gift} onClick={popout}></img>}
          {buchihide && <img className="buchi" src={buchhi}></img>}
          {pop && <Confetti numberOfPieces={350} width="1520%" height="720%"/>}
          { wish &&
          <div class="main">
              <h1 className="hbd">Wish you manyy more happieeeee <br/>returns of the dayyyy <div class="roller">
                  <span id="rolltext">
                  <span className="glowing-btn">M <span class='faulty-letter'>A</span> T H U</span><br />
                  <span className="glowing-btn">B <span class='faulty-letter'>L</span> I S S</span>
                  <br/>
                  <span className="glowing-btn">M <span class='faulty-letter'>A</span> A D U</span><br/>
                  <span className="glowing-btn">A <span class='faulty-letter'>N</span> G E L</span><br />
                  <span className="glowing-btn">B U <span class='faulty-letter'>J</span> U K S S E Y</span><br />
                  </span>
                  </div>
              </h1>
          </div>
          }
          </div>
      </div>
  )
}
